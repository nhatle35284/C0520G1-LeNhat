import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-structural',
  templateUrl: './structural.component.html',
  styleUrls: ['./structural.component.css']
})
export class StructuralComponent implements OnInit {
  public isShow: boolean = true;
  public username: string = "Hai Quay Xe";
  month:number = 18;
  name:string[] = ["Hai","Tra","Toan","Nhat"];

  constructor() {
  }

  ngOnInit(): void {
  }

}
