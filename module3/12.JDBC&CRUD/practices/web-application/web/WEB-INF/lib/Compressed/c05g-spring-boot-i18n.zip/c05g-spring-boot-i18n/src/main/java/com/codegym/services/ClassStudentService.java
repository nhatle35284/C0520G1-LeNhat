package com.codegym.services;

import com.codegym.models.ClassStudent;

import java.util.List;

public interface ClassStudentService {
    List<ClassStudent> findAll();
}
