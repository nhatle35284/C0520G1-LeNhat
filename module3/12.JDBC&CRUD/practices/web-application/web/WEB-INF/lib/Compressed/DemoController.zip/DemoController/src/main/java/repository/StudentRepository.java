package repository;

import model.Student;


public interface StudentRepository extends Repository<Student> {

}
