package vn.codegym.demo_jpa_repository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJpaRepositoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
