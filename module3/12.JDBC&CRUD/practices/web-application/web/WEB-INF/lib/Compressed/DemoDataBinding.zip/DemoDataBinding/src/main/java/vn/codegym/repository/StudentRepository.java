package vn.codegym.repository;

import vn.codegym.model.Student;


public interface StudentRepository extends Repository<Student> {

}
