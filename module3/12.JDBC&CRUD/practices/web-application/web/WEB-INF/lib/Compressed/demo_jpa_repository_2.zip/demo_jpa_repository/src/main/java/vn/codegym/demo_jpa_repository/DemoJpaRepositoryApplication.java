package vn.codegym.demo_jpa_repository;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaRepositoryApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoJpaRepositoryApplication.class, args);
    }

}
